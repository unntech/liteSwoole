-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- 主机： 10.100.112.6
-- 生成日期： 2025-06-17 22:54:13
-- 服务器版本： 5.7.44-log
-- PHP 版本： 8.2.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `lite_swoole`
--

-- --------------------------------------------------------

--
-- 表的结构 `alog`
--

CREATE TABLE `alog` (
  `id` int(4) NOT NULL,
  `type` varchar(100) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  `log1` text CHARACTER SET utf8mb4,
  `log2` text CHARACTER SET utf8mb4,
  `log3` text CHARACTER SET utf8mb4
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='log';

-- --------------------------------------------------------

--
-- 表的结构 `api_request_log`
--

CREATE TABLE `api_request_log` (
  `id` int(4) NOT NULL,
  `url` varchar(250) CHARACTER SET utf8mb4 NOT NULL DEFAULT '' COMMENT '请求方法',
  `params` varchar(1500) CHARACTER SET utf8mb4 NOT NULL COMMENT 'GET参数',
  `postdata` text CHARACTER SET utf8mb4 NOT NULL COMMENT '请求BODY',
  `ip` varchar(40) NOT NULL DEFAULT '' COMMENT 'IP',
  `addtime` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='API接口请求日志';

-- --------------------------------------------------------

--
-- 表的结构 `app_secret`
--

CREATE TABLE `app_secret` (
  `id` int(4) NOT NULL,
  `appid` varchar(32) NOT NULL DEFAULT '',
  `appsecret` varchar(100) NOT NULL DEFAULT '',
  `title` varchar(16) CHARACTER SET utf8mb4 NOT NULL DEFAULT '' COMMENT '名称',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0禁用，1生效，2期限',
  `expires` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='项目对接密钥';

--
-- 转存表中的数据 `app_secret`
--

INSERT INTO `app_secret` (`id`, `appid`, `appsecret`, `title`, `status`, `expires`) VALUES
(1, 'app313276672646586985', '481b9e180527e3ce790e85b43369ce64', '测试项目', 1, 0);

-- --------------------------------------------------------

--
-- 表的结构 `ws_clients`
--

CREATE TABLE `ws_clients` (
  `fd` int(4) UNSIGNED NOT NULL,
  `addtime` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT '上线时间',
  `remote_addr` varchar(42) NOT NULL DEFAULT '' COMMENT '来源IP',
  `sec_key` varchar(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='WebSocket 在线表';

--
-- 转储表的索引
--

--
-- 表的索引 `alog`
--
ALTER TABLE `alog`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `api_request_log`
--
ALTER TABLE `api_request_log`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `app_secret`
--
ALTER TABLE `app_secret`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `appid` (`appid`);

--
-- 表的索引 `ws_clients`
--
ALTER TABLE `ws_clients`
  ADD PRIMARY KEY (`fd`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `alog`
--
ALTER TABLE `alog`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `api_request_log`
--
ALTER TABLE `api_request_log`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `app_secret`
--
ALTER TABLE `app_secret`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
